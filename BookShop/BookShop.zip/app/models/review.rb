class Review < ApplicationRecord
    belongs_to :book
end
